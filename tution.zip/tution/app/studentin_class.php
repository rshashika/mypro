<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class studentin_class extends Model
{
    //
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tution extends Model
{
    //
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class attendence extends Model
{
    //
}

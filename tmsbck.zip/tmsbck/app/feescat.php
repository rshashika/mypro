<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class feescat extends Model
{
    //
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Paymentcategory extends Model
{
    //
}

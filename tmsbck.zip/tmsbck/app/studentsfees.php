<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class studentsfees extends Model
{
    //
}

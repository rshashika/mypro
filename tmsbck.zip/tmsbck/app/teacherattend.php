<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class teacherattend extends Model
{
    //
}

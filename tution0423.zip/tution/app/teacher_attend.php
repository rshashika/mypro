<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class teacher_attend extends Model
{
    //
}

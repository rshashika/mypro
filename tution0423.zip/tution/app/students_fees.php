<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class students_fees extends Model
{
    //
}
